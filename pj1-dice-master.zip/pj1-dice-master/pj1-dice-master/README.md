# lessa.codes/pj1-dice

## Entregar [aqui](https://goo.gl/forms/NnrnmDNTeZ6nUbJf2)

## B4 AV2 - Partículas Fabulosas (3pts)

Peguem essa demo e taca-lhe partículas pra ficar maneirin.

A ideia é adicionar uma partícula (ou mais) de efeito pra quando o dado
cai no chão. Por exemplo:

- Fumacinha
- Estrelinhas (ou quadradinhos girando também)
- Faíscas
- Outras coisas maneririnhas (a Unity é o limite!)

## Logística

Grupos de 2 a 4 seres humanos

Entregar [aqui](https://goo.gl/forms/NnrnmDNTeZ6nUbJf2) (link do seu repositório no github, pls)
